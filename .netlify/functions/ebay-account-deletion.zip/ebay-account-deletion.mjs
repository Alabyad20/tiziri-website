
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/ebay-account-deletion.mjs
import { createHash } from "node:crypto";
var VERIFICATION_TOKEN = process.env.EBAY_VERIFICATION_TOKEN;
var ENDPOINT_URL = "https://tizirirugs.com/api/ebay-account-deletion";
var ebay_account_deletion_default = async (req) => {
  const url = new URL(req.url);
  const challengeCode = url.searchParams.get("challenge_code");
  if (req.method === "GET" && challengeCode) {
    const challengeResponse = createHash("sha256").update(challengeCode + VERIFICATION_TOKEN + ENDPOINT_URL).digest("hex");
    return Response.json({ challengeResponse });
  }
  if (req.method === "POST") {
    return new Response(null, { status: 200 });
  }
  return new Response("Not found", { status: 404 });
};
var config = { path: "/api/ebay-account-deletion" };
export {
  config,
  ebay_account_deletion_default as default
};
